Name: Chandler Ford
Class: CSS 490 A
Assignment: Program 1 (Simple Crawl)

Included in zip file:
1) WebCrawler.exe: The executable for the application.
2) Program.cs: The C# file containing code.
3) ReadMe: Explanation of how to run.

How to run executable: 
1) Make sure you have WebCrawler.exe downloaded
2) Open Command Prompt
3) Navigate to the folder WebCrawler.exe is in
4) Once in the folder type the following:
	WebCrawler.exe [URL with http://] [Number of Hops]
   For example:
	WebCrawler.exe http://uwb.edu 5

*Make sure you include the http:// for the URL and use an integer for the number of hops - the program will notify the user if entered incorrectly.
